package com.cg.pla;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import jakarta.transaction.Transactional;

@Service
@Transactional
public class PlacementServices {
	
	@Autowired
	private PlacementRepository placementRepository;
	public Placement save(Placement placement) {
		return placementRepository.save(placement );
	}
	
	public List<Placement> readplacement(){
		return (List<Placement>) placementRepository.findAll();
	}
	
	public void deleteplacement(Integer id) {
		placementRepository.deleteById(id);
	}
	
	public Placement updateplacement(Placement placement) {
		Integer id = placement.getId();
		Placement place = placementRepository.findById(id).get();
		place.setName(placement.getName());
		place.setCollege(placement.getCollege());
		place.setDate(placement.getDate());
		place.setQualification(placement.getQualification());
		place.setYear(placement.getYear());
		return placementRepository.save(place);
	}
}
	
	
	
		

